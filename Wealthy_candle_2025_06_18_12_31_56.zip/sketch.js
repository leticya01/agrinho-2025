let divisionLineX; // Posição X da linha divisória
let transitionWidth = 50; // Largura da área de transição no centro

function setup() {
  createCanvas(800, 600);
  divisionLineX = width / 2; // Começa no meio da tela
}

function draw() {
  // Limpa o fundo a cada frame
  background(220);

  // --- Desenha o Lado do Campo (Esquerdo) ---
  push();
  // Limita o desenho do campo à esquerda da linha
  drawingContext.save(); // Salva o estado do contexto de desenho
  drawingContext.rect(0, 0, divisionLineX, height); // Define um clipe retangular
  drawingContext.clip(); // Aplica o clipe

  // Céu do Campo
  fill(135, 206, 235); // Azul claro
  rect(0, 0, width, height);

  // Grama
  fill(100, 200, 70); // Verde da grama
  rect(0, height * 0.7, width, height * 0.3);

  // Sol
  fill(255, 200, 0);
  ellipse(width * 0.2, height * 0.2, 80, 80);

  // Algumas árvores
  fill(90, 60, 30); // Tronco
  rect(width * 0.15, height * 0.5, 20, height * 0.2);
  fill(40, 120, 40); // Folhagem
  ellipse(width * 0.16, height * 0.5, 80, 80);

  rect(width * 0.4, height * 0.6, 15, height * 0.1);
  ellipse(width * 0.41, height * 0.6, 60, 60);

  drawingContext.restore(); // Restaura o estado do contexto (remove o clipe)
  pop();

  // --- Desenha o Lado da Cidade (Direito) ---
  push();
  // Limita o desenho da cidade à direita da linha
  drawingContext.save();
  drawingContext.rect(divisionLineX, 0, width - divisionLineX, height);
  drawingContext.clip();

  // Céu da Cidade (noturno ou poluído)
  fill(50, 50, 80); // Azul escuro/cinza
  rect(0, 0, width, height);

  // Rua/Chão da Cidade
  fill(80, 80, 80); // Cinza escuro
  rect(0, height * 0.7, width, height * 0.3);

  // Prédios
  let buildingColors = [
    color(120), color(100), color(140), color(90)
  ];
  let numBuildings = 6;
  for (let i = 0; i < numBuildings; i++) {
    let buildingWidth = random(50, 100);
    let buildingHeight = random(height * 0.3, height * 0.6);
    let buildingX = map(i, 0, numBuildings, divisionLineX + 50, width - buildingWidth - 20); // Posiciona à direita da linha

    fill(buildingColors[i % buildingColors.length]); // Alterna cores de prédio
    rect(buildingX, height - buildingHeight, buildingWidth, buildingHeight);

    // Janelas
    fill(255, 255, 150); // Amarelo das luzes
    let windowSize = 8;
    for (let y = height - buildingHeight + 15; y < height - 20; y += 20) {
      for (let x = buildingX + 10; x < buildingX + buildingWidth - 10; x += 18) {
        if (random() > 0.3) { // Algumas janelas acesas
          rect(x, y, windowSize, windowSize);
        }
      }
    }
  }

  drawingContext.restore();
  pop();

  // --- Linha divisória com transição ---
  // A linha segue o mouse, mas com suavidade
  divisionLineX = lerp(divisionLineX, mouseX, 0.1); // Suaviza o movimento da linha

  // Desenha uma área de transição suave na linha
  for (let i = 0; i < transitionWidth; i++) {
    let alpha = map(i, 0, transitionWidth, 0, 100); // Transparência crescente
    fill(0, 0, 0, alpha); // Cor da transição (pode ser preta, ou cinza, etc.)
    noStroke();
    rect(divisionLineX - transitionWidth / 2 + i, 0, 1, height);
  }

  // Linha central mais forte (opcional)
  stroke(0);
  strokeWeight(2);
  line(divisionLineX, 0, divisionLineX, height);
}